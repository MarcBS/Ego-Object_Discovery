addpath([pwd '/']);
addpath([pwd '/MEX/']);
display('Loading the default parameters ...');
load('defaultParameters.mat');
display('Updating the paths ...');
params = updatePath([pwd '/'],params);
