imgExample = imread('002053.jpg');
boxes = runObjectness(imgExample,20);
figure,imshow(imgExample),drawBoxes(boxes);