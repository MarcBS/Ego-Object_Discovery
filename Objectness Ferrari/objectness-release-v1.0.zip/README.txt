Objectness V 1.0
================

B. Alexe, T. Deselaers, V. Ferrari
{bogdan, deselaers, ferrari}@vision.ee.ethz.ch

This software was developed under Linux with Matlab R2010a.  There is
no guarantee it will run on other operating systems or Matlab versions
(though it probably will).

As a sub-component, this software uses the segmentation code of [2],
which is included in this release.  We thank the authors of [2] for
permission to redistribute their code as part of this release.


Introduction
------------

Welcome to this release of the objectness measure [1]. The objectness
measure quantifies how likely it is for an image window to contain an
object of any class.  This software computes the objectness measure
(MS+CC+SS) defined in [1] and allows to sample any desired number of
windows from an image according to their objectness probabilities. For
applications, we recommend to sample about 1000 windows, which ensures
covering most objects even in difficult images (e.g. with small
objects and lots of clutter). However, in images of normal difficulty
100 windows should be sufficient.

In addition to the source code, we also release 10000 windows sampled
from the objectness measure for every image from PASCAL 2007 VOC
[3]. These ready-to-use windows should facilitate applications on this
dataset.


Quick start
-----------
Let <dir> be the directory where you uncompressed the release archive

cd <dir>
cd segment
make           # compiles the segmentation tool [2]
cd ..
matlab         
enter  'demo' in Matlab

demo.m does the following: 
loads the image 002053.jpg
computes the objectness probability for all windows in this image
random samples 10 windows according to their objectness
displays the 10 windows (brighter windows have higher objectness)

Sanity check:
if the figure that appears at step 4 of demo.m has several bright red
windows on the train, then the code is working properly.


Setting things up
-----------------
The only mandatory operations are:

  1. add the code to the Matlab path (this is carried out in startup.m)
     
  2. load the parameters in defaultParameters.mat and update the paths
     (this is carried out in startup.m)

  3. compile the segmentation tool [2] (step 3 in 'Quick start'):
     enter 'make' in a shell inside the 'segment' directory


Another optional operation (recommended):

  4. the variable dir_root in runObjectness.m is set to `pwd` to work
     directly as detailed in 'Quick start'. We recommend to move your
     data elsewhere and update dir_root accordingly. In this way the
     program will work regardless of the current working directory.


Re-training objectness using your dataset
-----------------------------------------

In this release we include the objectness measure already trained from
50 images (see [1]) and ready to run on new images.  To speed up the
computation of the objectness measure in the release version we use
another quantization for the CC cue. To obtain the original parameters
used to obtain the results in figure 9c, curve MS+CC+SS of [1] please
set params.CC.quant = [8 16 16]. Using this new, coarser quantization
the performance of the objectness measure is almost the same: 0.248
ALC (compared to 0.251 with the finer quantization).

 
We include here software for re-training the parameters of objectness
using another training set.  For this do:


1. put the training images in a different folder (called hereafter
   'NewTrainingFolder')

2. build a struct analog to structGT from [<dir> '/Training/Images/']
   and save it in NewTrainingFolder under the name 'structGT.mat'.
   This struct should have two fields: the name of the images (field
   'img') in NewTrainingFolder and ground-truth bounding-boxes for
   each object in the image (field 'boxes').

3. run the function learnParameters using as a input the absolute path
   of 'NewTrainingFolder' (variable pathNewTrainingFolder).  This
   function learns the parameters of the objectness measure using the
   images in the 'NewTrainingFolder' and saves the learned parameters
   in [<dir> '/Data/yourData/']. In order to run the software using
   the learned parameters set params.data = [<dir> '/Data/yourData/'].


Ready-to-use objectness windows for VOC PASCAL 07
-------------------------------------------------

This release includes 10000 ready-to-use windows sampled from the
objectness measure, for every image in the VOC PASCAL 07 dataset
[3]. This data is released in a second archive. It is grouped in two
subdirectories: VOCtest and VOCtrainval (as in [3]).  For every image,
there is one file containing 10000 lines. Every line stores a window
represented as [xmin ymin xmax ymax prob], where 'prob' is the
estimated probability that the window contains an object (i.e. its
objectness score).

If you want to use only N windows from an image (N<10000) you can use
the first N lines of these files. This will preserve the distribution
of objectness.


Matlab Functions
----------------

runObjectness
-------------
windows = runObjectness(img, numberSamples, params);

computes the objectness measure for a given image and samples from it.

Input:
    img - input image;
    numberSamples - number of samples (windows) to be drawn from the objectness distribution;
    params - parameters used to compute the objectness measure (they are loaded during the startup).

Output:
    windows(i,:) = [xmin ymin xmax ymax score]  set of the windows sampled.


learnParameters
---------------
params = learnParameters(pathNewTrainingFolder,dir_root);

learns the parameters of the objectness measure.

Input:
    pathNewTrainingFolder - absolute path of 'NewTrainingFolder';
    dir_root - path to the objectness code (see Setting things up).


Support
-------

For any query/suggestion/complaint or simply to say you like/use this
software, just drop us an email:

bogdan@vision.ee.ethz.ch  (please contact this address first)
deselaers@vision.ee.ethz.ch
ferrari@vision.ee.ethz.ch

We wish you a good time using this software,

  Bogdan Alexe
  Thomas Deselaers
  Vittorio Ferrari



References
----------
[1] Bogdan Alexe, Thomas Deselaers and Vittorio Ferrari
    What is an object?,
    CVPR 2010, San Francisco, USA

[2] P. F. Felzenszwalb and D. P. Huttenlocher
    Efficient graph-based image segmentation,
    IJCV, 2004
    http://people.cs.uchicago.edu/~pff/segment/

[3] M. Everingham, L. Van Gool, C. Williams, J. Winn, and A. Zisermann
    The PASCAL Visual Object Classes Challenge 2007.


Versions history
----------------

1.0
---
- first public release
- included ready-to-use windows for PASCAL VOC 07


0.9
---
- First semi-internal release for testers

